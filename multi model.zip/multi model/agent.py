goal="find the todays weather"
print("goal:", goal)
print("planning...!")
steps=[
    "search the weather api",
    "prioritize the location",
    "read the results",
    "summarize"
]
for i in steps:
    print("executing:", i)
    print()
print("goal finished!")

# WAP to understand agent wrokflow

goal_completed=False

while not goal_completed:
    print("Thinking...!")
    action=input("enter the next action:")

    if action=="search ":
        print("Searching")      
        print("obeservation:Articles found")
    elif action=="read":
        print("searching")
        print("read:the articles")
    elif action=="reasoning":
        print("reasoning...")
        print("why/what we need...!")
    elif action=="finish":
        print("goal completed")
        goal_completed=True
print("task completed")

# WAP to understand FUNCTION CALLING
def weather(city):
    return {
        "city": city,
        "temperature": "39°C",
        "condition": "sunny"
    }

# calling the function
result = weather("banglore")
print("weather summery at:", result)

# WAP to implement calculator using func decleration
def add(a, b):
    return a + b
def sub(a, b):
    return a - b
def mul(a, b):
    return a * b
def div(a, b):
        return a / b
def mod(a, b):
    return a % b
op=input("enter the operation:")
if "add" in op.lower():
   nums=[int(x) for x in op.split() if x.isdigit()]
   result=add(nums[0], nums[1])
elif "sub" in op.lower():
    nums=[int(x) for x in op.split() if x.isdigit()]
    result=sub(nums[0],nums[1])
    print("Subtraction:", result)
elif "mul" in op.lower():
    nums=[int(x) for x in op.split() if x.isdigit()]
    result=mul(nums[0],nums[1])
    print("multiplition:", result)
elif "div" in op.lower():
    nums=[int(x) for x in op.split() if x.isdigit()]
    result=div(nums[0],nums[1])
    print("Division:", result)
elif "mod" in op.lower():
    nums=[int(x) for x in op.split() if x.isdigit()]
    result=mod(nums[0],nums[1])
    print("Modulus:", result)
else:
    print("invalid operation")